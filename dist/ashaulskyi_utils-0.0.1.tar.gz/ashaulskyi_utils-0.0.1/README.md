# AShaulskyi utils

It is a small package that contains web development utils that I frequently use.

## Motivation

1) Learn to publish python packages on PYPI.
2) These utils are frequently used in my pet projects so a published package makes it much easier to use them.

## Installation

```bash
pip install ashaulskyi-utils
```
